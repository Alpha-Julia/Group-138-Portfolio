// Get the objects we need to modify
let addPokemonSpeciesForm = document.getElementById('add-PokemonSpecies-form-ajax');

// Modify the objects we need
addPokemonSpeciesForm.addEventListener("submit", function (e) {
    
    // Prevent the form from submitting
    e.preventDefault();

    // Get form fields we need to get data from
    let inputSpeciesID = document.getElementById("input-id");
    let inputSpeciesName = document.getElementById("input-name");
    let inputBaseHP = document.getElementById("input-baseHP");
    let inputBaseAtk = document.getElementById("input-baseAtk");
    let inputBaseDef = document.getElementById("input-baseDef");
    let inputBaseSpAtk = document.getElementById("input-baseSpDef");
    let inputBaseSpDef = document.getElementById("input-baseSpeed");
    let inputTyping = document.getElementById("input-typing");

    // Get the values from the form fields
    let SpeciesIDValue = inputSpeciesID.value;
    let SpeciesNameValue = inputSpeciesName.value;
    let BaseHPValue = inputBaseHP.value;
    let BaseAtkValue = inputBaseAtk.value;
    let BaseDefValue = inputBaseDef.value;
    let BaseSpAtkValue = inputBaseSpAtk.value;
    let BaseSpDefValue = inputBaseSpDef.value;
    let TypingValue = inputTyping.value;

    // Put our data we want to send in a javascript object
    let data = {
        speciesID: SpeciesIDValue,
        speciesName: SpeciesNameValue,
        baseHP: BaseHPValue,
        baseAtk: BaseAtkValue,
        baseDef: BaseDefValue,
        baseSpAtk: BaseSpAtkValue,
        baseSpDef: BaseSpDefValue,
        typing: TypingValue

    }
    
    // Setup our AJAX request
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "/add-pokemonSpecies-ajax", true);
    xhttp.setRequestHeader("Content-type", "application/json");

    // Tell our AJAX request how to resolve
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {

            // Add the new data to the table
            addRowToTable(xhttp.response);

            // Clear the input fields for another transaction
            inputSpeciesID.value = '' ;
            inputSpeciesName.value = '';
            inputBaseHP.value = ''; 
            inputBaseAtk.value = ''; 
            inputBaseDef.value = ''; 
            inputBaseSpAtk.value = ''; 
            inputBaseSpDef.value = '';
            inputTyping.value = ''; 
        }
        else if (xhttp.readyState == 4 && xhttp.status != 200) {
            console.log("There was an error with the input.")
        }
    }

    // Send the request and wait for the response
    xhttp.send(JSON.stringify(data));

})


// Creates a single row from an Object representing a single record from 
// bsg_people
addRowToTable = (data) => {

    // Get a reference to the current table on the page and clear it out.
    let currentTable = document.getElementById("speciesID-table");

    // Get the location where we should insert the new row (end of table)
    let newRowIndex = currentTable.rows.length;

    // Get a reference to the new row from the database query (last object)
    let parsedData = JSON.parse(data);
    let newRow = parsedData[parsedData.length - 1]

    // Create a row and 4 cells
    let row = document.createElement("TR");
    let idCell = document.createElement("TD");
    let nameCell = document.createElement("TD");
    let baseHPCell = document.createElement("TD");
    let baseDefCell = document.createElement("TD");
    let baseSpAtkCell = document.createElement("TD");
    let baseSpDefCell = document.createElement("TD");
    let baseSpeedCell = document.createElement("TD");
    let typingCell = document.createElement("TD");

    // Fill the cells with correct data
    idCell.innerText = newRow.speciesID;
    nameCell.innerText = newRow.speciesName;
    baseHPCell.innerText = newRow.baseHP;
    baseDefCell.innerText = newRow.baseAtk;
    baseSpAtkCell.innerText = newRow.baseDef;
    baseSpDefCell.innerText = newRow.baseSpAtk;
    baseSpeedCell.innerText = newRow.baseSpDef;
    typingCell.innerText = newRow.typing;

    // Add the cells to the row 
    row.appendChild(idCell);
    row.appendChild(nameCell);
    row.appendChild(baseHPCell);
    row.appendChild(baseDefCell);
    row.appendChild(baseSpAtkCell);
    row.appendChild(baseSpDefCell);
    row.appendChild(baseSpeedCell);
    row.appendChild(typingCell);

    
    // Add the row to the table
    currentTable.appendChild(row);
}